package uz.makhmudjon.whether.ui.details.adapters.future

import android.support.v7.widget.RecyclerView
import android.view.View

class FViewHolder(v: View) : RecyclerView.ViewHolder(v)