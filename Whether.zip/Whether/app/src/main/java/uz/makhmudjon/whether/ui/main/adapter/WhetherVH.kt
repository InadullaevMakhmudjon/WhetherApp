package uz.makhmudjon.whether.ui.main.adapter

import android.support.v7.widget.RecyclerView
import android.view.View

class WhetherVH(v: View):RecyclerView.ViewHolder(v) {
}