package uz.makhmudjon.whether.ui.details.adapters.today

import android.support.v7.widget.RecyclerView
import android.view.View

class TViewHolder(v: View):RecyclerView.ViewHolder(v)